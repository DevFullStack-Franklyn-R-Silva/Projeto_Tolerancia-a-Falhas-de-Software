package br.ufal.aracomp.cosmos.limite3.spec.prov;

import br.ufal.aracomp.cosmos.limite3.spec.dt.ClienteDT3;

public interface ILimiteOps3 {
	public double calcularLimite(ClienteDT3 client);
}
