package br.ufal.aracomp.cosmos.limite2.spec.prov;

import br.ufal.aracomp.cosmos.limite2.spec.dt.ClienteDT2;

public interface ILimiteOps2 {
	public double calcularLimite(ClienteDT2 client);
}
