package br.ufal.aracomp.cosmos.limite2.spec.dt;

public class ClienteDT2 {
	public double salario;
	//TODO complete information
}
